1. To install the entry into the crontab
   * * * * * root /usr/bin/python3 <path of the file>/ips.py -a 3 -t 3 -d 3
